import pandas as pd

df = pd.read_csv("sales_data.csv")

pivot = pd.pivot_table(
    df,
    index="Item",
    values="Units",
    aggfunc="sum"
)

print("Item-wise Units Sold:")
print(pivot)